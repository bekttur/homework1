const http = require('http');
const querystring = require("querystring");

let students = [];

function handler(request, response) {
    if(request.url === "/getStudents"){
        if(request.method === "GET"){
            response.write(JSON.stringify(students));
        }
    }else if(request.url === "/addStudent"){
        if(request.method === "POST"){
            let body = '';

            request.on("data", data => {
                body += data;
            });

            request.on("end", () => {
                let requestBody = querystring.parse(body);
                let studentObject = {
                    fullName: requestBody.fullName,
                    groupName: requestBody.groupName
                }
                students.push(studentObject);
            })
        }
    } else if(request.url === "clear"){
        if(request.method === "POST"){
            students = [];
            response.write("clear");
        }
    }

    response.end();
}

let server = http.createServer(handler);

server.listen(8080);